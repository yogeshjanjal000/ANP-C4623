package com.sports.testplayerserviceimpl;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.sports.entity.PlayerEntity;
import com.sports.repository.PlayerRepository;
import com.sports.service.PlayerService;
import com.sports.util.PlayerConverter;
@SpringBootTest
public class PlayerServiceIMPL {
	@Autowired
	private PlayerService playerservice;
	@Autowired
	private PlayerConverter playerconverter;
	@MockBean
	private PlayerRepository playerrepository;

	@Test
	void testSavePlayer() {
		PlayerEntity player = new PlayerEntity();
		player.setPlayerName("Sunil");
		player.setPlayerTeam("IndianSoccer");
		player.setPlaySports("FootBall");
	
		Mockito.when(playerrepository.save(player)).thenReturn(player);
		assertThat(playerservice.createplayer(player)).isEqualTo("Player details saved successfuly");
	}
}
