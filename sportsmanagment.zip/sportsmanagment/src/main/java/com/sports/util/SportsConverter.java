package com.sports.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.sports.dto.SportsDTO;
import com.sports.entity.SportsEntity;
@Component
public class SportsConverter {
	//convert the sportsDTO to sprotsentity(tosportsDTO,fromsprots )
			public SportsEntity convertToEntity( SportsDTO sportsDTO) 
			{
				SportsEntity sports= new SportsEntity();
				if(sportsDTO!=null)
		   	 {
		   		 BeanUtils.copyProperties(sportsDTO, sports);
		   	 }
		   	 return sports;
		   }
			//convert the sports to sportsDTO(tosports,fromsportsDTO)
			public SportsDTO convertToSportsDTO(SportsEntity sports)
			{
				SportsDTO sportsDTO = new SportsDTO();
				if(sports!=null)
				{
					BeanUtils.copyProperties(sports,sportsDTO);	
				}
				return sportsDTO;
		}
		}

 

