package com.sports.service;

import java.util.List;


import com.sports.dto.PlayerDTO;
import com.sports.entity.PlayerEntity;

public interface PlayerService {

	String createplayer(PlayerEntity player);

	PlayerDTO updatePlayer(int id, PlayerEntity player);

	PlayerDTO getPlayer(int id);

	List<PlayerDTO> getAllPlayer();

	String deletePlayerById(int id);

	PlayerDTO assignSportToPlayer(int id, int sportsid);

	PlayerDTO assignSportsToPlayer(int id, int sportsid);

}
