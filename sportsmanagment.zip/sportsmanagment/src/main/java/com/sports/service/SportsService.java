package com.sports.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sports.dto.SportsDTO;
import com.sports.entity.SportsEntity;
@Service
public interface SportsService {

	String createSports(SportsEntity sports);

	SportsDTO updateSports(int id, SportsEntity sports);

	SportsDTO getSports(int id);

	List<SportsDTO> getAllSports();

	String deleteSportsById(int id);

	void deleteAllSports();

}
