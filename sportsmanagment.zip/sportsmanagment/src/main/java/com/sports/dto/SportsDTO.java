package com.sports.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SportsDTO {
	 
		private  int sportsid;
		private String sportsname;
		private String location;
		private String teamname;
		private float duration;
}
