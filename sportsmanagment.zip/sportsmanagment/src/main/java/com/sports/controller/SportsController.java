package com.sports.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sports.dto.SportsDTO;
import com.sports.entity.SportsEntity;
import com.sports.service.SportsService;
import com.sports.util.SportsConverter;







@RestController
public class SportsController {
	@Autowired
	private SportsService sportsservice;
	@Autowired
	private SportsConverter sportsconverter;
	@PostMapping ("/createsports")
	public String createSports(@RequestBody SportsDTO sportsDTO)
	{
		final SportsEntity sports= sportsconverter.convertToEntity(sportsDTO);
		 return sportsservice.createSports(sports);
	}
	@PutMapping("/updatesports/(identity)")
	 public SportsDTO updateSports(@PathVariable("identity") int id, @RequestBody SportsDTO sportsDTO)
	  {
		 SportsEntity sports= sportsconverter.convertToEntity(sportsDTO);
		  return sportsservice.updateSports(id, sports);
	  }
	@GetMapping("/getSports/{identity}")
    public SportsDTO getSports(@PathVariable("identity") int id)
    {
    return sportsservice.getSports(id);
    	
    }
	@GetMapping("/getAllSports")
    public List<SportsDTO> getAllSports()
    {
    	return sportsservice.getAllSports();
    }
	@DeleteMapping("/deleteSportsById/{id}")
    public String deleteSportsById(@PathVariable("id") int id)
    {
    	return sportsservice.deleteSportsById(id);
    	
    }
	@DeleteMapping("/deleteAllSports")
    public void deleteAllSports()
    {
    	sportsservice.deleteAllSports();
    	
    }
}
